const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

let items = [];

// Get all items
app.get('/api/items', (req, res) => {
  res.json(items);
});

// Create a new item
app.post('/api/items', (req, res) => {
  const item = { id: Date.now(), ...req.body };
  items.push(item);
  res.status(201).json(item);
});

// Update an item by ID
app.put('/api/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  items = items.map(i => i.id === id ? { ...i, ...req.body } : i);
  res.json({ message: 'updated' });
});

// Delete an item by ID
app.delete('/api/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  items = items.filter(i => i.id !== id);
  res.json({ message: 'deleted' });
});

// Start the server
app.listen(4000, () => console.log('Server running on port 4000'));