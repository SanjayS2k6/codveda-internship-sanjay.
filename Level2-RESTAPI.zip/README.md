# Level 2 - REST API using Node.js and Express.js

## 🚀 Project Overview
This is a simple CRUD REST API for managing "items". It is built with Node.js and Express.js.

## 🧰 Tech Stack
- Node.js
- Express.js
- CORS
- Nodemon (optional for auto-reload)

## 📦 Installation
```bash
npm install
node server.js
```
or, with nodemon:
```bash
npx nodemon server.js
```

## 🔗 API Endpoints

| Method | Endpoint | Description |
|--------|-----------|-------------|
| GET | `/api/items` | Get all items |
| POST | `/api/items` | Add a new item |
| PUT | `/api/items/:id` | Update an item |
| DELETE | `/api/items/:id` | Delete an item |

### Example JSON (POST /api/items)
```json
{
  "name": "Sample Item",
  "price": 200
}
```

## 🧪 Testing
Use Postman or Thunder Client:
1. Run the server using `node server.js`
2. Test each endpoint (GET, POST, PUT, DELETE)

## 🌐 Output
A running API at: `http://localhost:4000/api/items`
